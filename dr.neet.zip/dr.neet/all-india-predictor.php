<?php include_once("includes/pagesource.php"); ?>

<body style="    background: whitesmoke;">
    <?php include_once("includes/header.php"); ?>
    <div class="inner-banner banner position-relative predicter-banner">
        <img src="images/GettyImages-551427839-56a492fb3df78cf772830b4f.jpg">
        <div class="banner-inner-content">
            <div class="text-center w-100">
                <h2 class="text-white mb-3">All India Predictor</h2>
            </div>
        </div>
    </div>
    <div class="bottom-header menu-2" style="padding: 15px;">
        <div class="container">
            <div class="row">
                <div class="menu-box menu-2-box h-auto py-4" id="collapsemenu">
                    <div class="d-md-flex align-itmes-centre justify-content-between">
                        <input class="form-control mb-2 mb-md-0 mr-md-2" type="text" placeholder="Neet Score">
                        <select class="form-control mb-2 mb-md-0 mr-md-2" id="course">
                            <option value="">SELECT COUNSELLING TYPE</option>
                        </select>
                        <select class="form-control mb-2 mb-md-0 mr-md-2" id="category">
                            <option value="">SELECT CATEGORY</option>
                        </select>
                        <div class="d-flex align-itmes-centre justify-content-center">
                            <button type="button" onclick="submit_rank('page')" class="rounded main-btn-bk border-0 py-2 px-4 text-white ">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid testi py-6 position-relative" id="testi">
        <div class="container position-relative">
            <div class="row">
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">All India Counseling Colleges & Seats 2020</h2>
                        <div class="post-body">
                            <?php include_once("includes/map.php"); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-0">
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <div class="d-flex">
                                <button class="clgbtn clgbtn20 active" onclick="$('.c2020').show(); $('.c2019').hide(); $('.clgbtn20').addClass('active'); $('.clgbtn19').removeClass('active'); ">No. of Colleges 2020</button>
                                <button class="clgbtn clgbtn19" onclick="$('.c2020').hide(); $('.c2019').show(); $('.clgbtn20').removeClass('active'); $('.clgbtn19').addClass('active');">No. of Colleges 2019</button>

                            </div>
                            <div class="post-body">
                                <div class="colage-wrap c2020">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>100</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>100</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="colage-wrap c2019" style="display: none;">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>200</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>50</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="indicate">
                                    <p class="demed-ind"><span></span>Deemed</p>
                                    <p class="gov-ind"><span></span>Goverment</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <div class="d-flex">
                                <button class="clgbtn seatbtn20 active" onclick="$('.s2020').show(); $('.s2019').hide(); $('.seatbtn20').addClass('active'); $('.seatbtn19').removeClass('active'); ">No. of Colleges 2020</button>
                                <button class="clgbtn seatbtn19" onclick="$('.s2020').hide(); $('.s2019').show(); $('.seatbtn20').removeClass('active'); $('.seatbtn19').addClass('active');">No. of Colleges 2019</button>

                            </div>
                            <div class="post-body">
                                <div class="colage-wrap s2020">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>100</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>100</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="colage-wrap s2019" style="display: none;">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>200</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>50</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="indicate">
                                    <p class="demed-ind"><span></span>Deemed</p>
                                    <p class="gov-ind"><span></span>Goverment</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 p-0">
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <h2 class="post-head">Cutoff Rank MCC College</h2>
                            <div class="post-body">
                                <div class="progress-grid">
                                    <div class="progress-cell">
                                        <p>AIIMS</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>JIPMER-KAR</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>JIPMER-PUD</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>IPU</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>DU</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>BHU</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>AMU</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <h2 class="post-head">Cutoff Rank AIIMS</h2>
                            <div class="post-body">
                                <div class="progress-grid">
                                    <div class="progress-cell">
                                        <p>DELHI</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>BHUBNESHWAR</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>BHOPAL</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>JODHPUR</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>RISHIKESH</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>RAIPUR</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-cell">
                                        <p>PATNA</p>
                                        <div class="prgs-meter">
                                            <div class="meter orange">
                                                <span data-progress="100" style="width:0; background:rgb(0, 192, 207);"></span>
                                                <i class="prg-counter">100</i>
                                            </div>
                                            <div class="meter orange">
                                                <span data-progress="50" style="width:0; background:rgb(166 0 216);"></span>
                                                <i class="prg-counter">50</i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Domicile Condition</h2>
                        <div class="post-body">
                            <div class="costshift-box">
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#6d53dc">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#6d53dc;">15% Government/AIQ</h4>
                                        <h5>Open for All</h5>
                                    </div>
                                </div>
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#dc5356">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#dc5356;">10% Deemed</h4>
                                        <h5>Open for All</h5>
                                    </div>
                                </div>
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#138a3a">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#138a3a;">85% DU & IP University</h4>
                                        <h5>Delhi Domicile Only</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">No of Colleges</h2>
                        <div class="post-body">
                            <canvas id="myChart6" class="wow"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Cutoff Rank AIQ Government Seats</h2>
                        <div class="post-body">
                            <canvas id="myChart" class="wow"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">New MBBS Seats in 2020</h2>
                        <div class="post-body">
                            <div class="tran-list">
                                <ul class="tr-list">
                                    <li>DEEMED</li>
                                    <li>AIQ</li>
                                    <li>JIPMER</li>
                                    <li>AIIMS</li>
                                </ul>
                            </div>
                            <div id="triangle-down"><span>1400</span></div>
                            <div id="triangle-down1"><span>325</span></div>
                            <div id="triangle-down2"><span>250</span></div>
                            <div id="triangle-down0"><span>200</span></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">No of Seats</h2>
                        <div class="post-body">
                            <canvas id="myChart5" class="wow"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Top 10 States Cutoff Rank 2020</h2>
                        <div class="post-body">
                            <canvas id="myChart1" class="wow"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Top 10 Government Cutoff 2020</h2>
                        <div class="post-body">
                            <table class="table table-1">
                                <thead>
                                    <tr>
                                        <th class="uni" scope="col">College</th>
                                        <th class="fet" scope="col">NEET Rank</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Maulana Azad Medical College, Delhi</td>
                                        <td class="con">90</td>
                                    </tr>
                                    <tr>
                                        <td>VMMC &amp; Safdurjung Hospital, Delhi</td>
                                        <td class="con">163</td>
                                    </tr>
                                    <tr>
                                        <td>Dr. Ram Manohar Lohia Hospital, Delhi</td>
                                        <td class="con">448</td>
                                    </tr>
                                    <tr>
                                        <td>GMC &amp; Hospital, Chandigarh</td>
                                        <td class="con">776</td>
                                    </tr>
                                    <tr>
                                        <td>Madras Medical College, Chennai</td>
                                        <td class="con">934</td>
                                    </tr>
                                    <tr>
                                        <td>King Edward Memorial Hospital, Mumbai</td>
                                        <td class="con">935</td>
                                    </tr>
                                    <tr>
                                        <td>Banaras Hindu University, Varanasi</td>
                                        <td class="con">970</td>
                                    </tr>
                                    <tr>
                                        <td>B.J.Medical College, Ahemadabad</td>
                                        <td class="con">979</td>
                                    </tr>
                                    <tr>
                                        <td>Sawai ManSingh Medical College, Jaipur</td>
                                        <td class="con">1212</td>
                                    </tr>
                                    <tr>
                                        <td>Dr. Baba Saheb Ambedkar Hospital, Delhi</td>
                                        <td class="con">1216</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Top 10 AIIMS Cutoff 2020</h2>
                        <div class="post-body">
                            <table class="table table-1">
                                <thead>
                                    <tr>
                                        <th class="uni" scope="col">College</th>
                                        <th class="fet" scope="col">NEET Rank</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>AIIMS, New Delhi</td>
                                        <td class="con">51</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Bhubneshwar</td>
                                        <td class="con">586</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Bhopal</td>
                                        <td class="con">614</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Jodhpur</td>
                                        <td class="con">790</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Rishikesh</td>
                                        <td class="con">1366</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Raipur</td>
                                        <td class="con">1593</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Patna</td>
                                        <td class="con">1984</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Nagpur</td>
                                        <td class="con">2627</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Bathinda</td>
                                        <td class="con">3424</td>
                                    </tr>
                                    <tr>
                                        <td>AIIMS, Mangalagiri</td>
                                        <td class="con">3769</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Top 10 Deemed University Cutoff 2020</h2>
                        <div class="post-body">
                            <table class="table table-1">
                                <thead>
                                    <tr>
                                        <th class="uni" scope="col">College</th>
                                        <th class="fet" scope="col">NEET Rank</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Hamdard Institute of Medical Sciences, Delhi</td>
                                        <td class="con">28217</td>
                                    </tr>
                                    <tr>
                                        <td>Kasturba Medical College, Manipal</td>
                                        <td class="con">34613</td>
                                    </tr>
                                    <tr>
                                        <td>Kasturba Medical College, Mangalore</td>
                                        <td class="con">46159</td>
                                    </tr>
                                    <tr>
                                        <td>Jss Medical College, Mysore</td>
                                        <td class="con">64322</td>
                                    </tr>
                                    <tr>
                                        <td>Symbiosis Medical College for Women, Pune</td>
                                        <td class="con">64766</td>
                                    </tr>
                                    <tr>
                                        <td>K.S Hegde Medical Academy, Mangalore</td>
                                        <td class="con">94299</td>
                                    </tr>
                                    <tr>
                                        <td>Rural Medical College PIMS, Loni</td>
                                        <td class="con">96039</td>
                                    </tr>
                                    <tr>
                                        <td>Sri Devaraj Urs Medical College, Kolar</td>
                                        <td class="con">116153</td>
                                    </tr>
                                    <tr>
                                        <td>Jawahar Lal Nehru Medical College, Belgavi</td>
                                        <td class="con">146487</td>
                                    </tr>
                                    <tr>
                                        <td>Sri Ramachandra University, Chennai</td>
                                        <td class="con">179057</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">MCC Counselling Statistics - NEET 2020</h2>
                        <div class="post-body">
                            <table class="table table-1 gov-1">
                                <thead>
                                    <tr>
                                        <th class="uni seat-1" scope="col">College</th>
                                        <th class="fet seat" scope="col">State</th>
                                        <th class="uni seat" scope="col">City</th>
                                        <th class="fet seat" scope="col">College Type</th>
                                        <th class="uni seat-1" scope="col">Catagory</th>
                                        <th class="uni seat-1" scope="col">Annual Fees</th>
                                        <th class="fet seat-1" scope="col">Cutoff R1 Score</th>
                                        <th class="uni seat-1" scope="col">Cutoff R2 Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>AIIMS, New Delhi</td>
                                        <td>Delhi</td>
                                        <td>New Delhi</td>
                                        <td>Government</td>
                                        <td>GENERAL</td>
                                        <td>1628</td>
                                        <td>704</td>
                                        <td>704</td>
                                    </tr>
                                    <tr>
                                        <td>Maulana Azad Medical College</td>
                                        <td>Delhi</td>
                                        <td>Delhi</td>
                                        <td>Government</td>
                                        <td>GENERAL</td>
                                        <td>2445</td>
                                        <td>700</td>
                                        <td>700</td>
                                    </tr>
                                    <tr>
                                        <td>VMMC AND SAFDARJUNG HOSPITAL, NEW DELHI</td>
                                        <td>Delhi</td>
                                        <td>Delhi</td>
                                        <td>Government</td>
                                        <td>GENERAL</td>
                                        <td>36000</td>
                                        <td>694</td>
                                        <td>694</td>
                                    </tr>
                                    <tr>
                                        <td>VMMC AND SAFDARJUNG HOSPITAL, NEW DELHI</td>
                                        <td>Delhi</td>
                                        <td>Delhi</td>
                                        <td>Government</td>
                                        <td>GENERAL</td>
                                        <td>36000</td>
                                        <td>694</td>
                                        <td>694</td>
                                    </tr>
                                    <tr>
                                        <td>University College of Medical Sciences, New Delhi</td>
                                        <td>Delhi</td>
                                        <td>Delhi</td>
                                        <td>Government</td>
                                        <td>GENERAL</td>
                                        <td>5295</td>
                                        <td>690</td>
                                        <td>689</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("includes/footer.php"); ?>

</body>
<script>
    var ctx = document.getElementById("myChart");
    ctx.height = 170;
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Generl", "OBC", "SC", "ST"],
            datasets: [{
                label: 'Round 1',
                data: [120000, 190000, 30000, 170000],
                backgroundColor: "#fdaf4b"
            }, {
                label: 'Round 2',
                data: [30000, 290000, 500000, 5000000],
                backgroundColor: "#5fb7e5"
            }]
        },

    });
</script>
<script>
    var ctx1 = document.getElementById("myChart1");
    ctx1.height = 170;
    var myChart1 = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: ["Delhi", "Mumbai", "Goa", "Punjab", "Rajasthan"],
            datasets: [{
                label: "Cutoff Rank 2020",
                data: [2000, 9000, 3000, 7000, 8000],
                backgroundColor: "#00bb1300",
                borderColor: "#d60da4"
            }, ]
        },

    });
</script>
<script>
    var ctx5 = document.getElementById("myChart5");
    ctx5.height = 90;
    var myChart5 = new Chart(ctx5, {
        type: 'doughnut',
        data: {
            labels: ["AFMC", "IP University", "Delhi University", "Central University", "JIPMER", "AIIMS"],
            datasets: [{
                backgroundColor: [
                    "#0f3c59",
                    "#ff003f",
                    "#d60da4",
                    "#fdaf4b",
                    "#5fb7e5",
                    "#00863f"
                ],

                data: [10, 30, 20, 5, 25, 20]
            }]
        }
    });
</script>
<script>
    var ctx6 = document.getElementById("myChart6");
    ctx6.height = 90;
    var myChart6 = new Chart(ctx6, {
        type: 'doughnut',
        data: {
            labels: ["AFMC", "IP University", "Delhi University", "Central University", "JIPMER", "AIIMS"],
            datasets: [{
                backgroundColor: [
                    "#0f3c59",
                    "#ff003f",
                    "#d60da4",
                    "#fdaf4b",
                    "#5fb7e5",
                    "#00863f"
                ],

                data: [10, 30, 20, 5, 25, 20]
            }]
        }
    });
</script>
<script>
    var bars = document.querySelectorAll('.meter > span');
    console.clear();

    setInterval(function() {
        bars.forEach(function(bar) {
            var getWidth = parseFloat(bar.dataset.progress);

            for (var i = 0; i < getWidth; i++) {
                bar.style.width = i + '%';
            }
        });
    }, 500);
</script>

</html>