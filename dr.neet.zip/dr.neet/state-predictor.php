<?php include_once("includes/pagesource.php"); ?>

<body style="    background: whitesmoke;">
    <?php include_once("includes/header.php"); ?>
    <div class="inner-banner banner position-relative predicter-banner">
        <img src="images/GettyImages-551427839-56a492fb3df78cf772830b4f.jpg">
        <div class="banner-inner-content">
            <div class="text-center w-100">
                <h2 class="text-white mb-3">State Predictor</h2>
            </div>
        </div>
    </div>
    <div class="bottom-header menu-2" style="padding: 15px;">
        <div class="container">
            <div class="row">
                <div class="menu-box menu-2-box h-auto py-4" id="collapsemenu">
                    <div class="d-md-flex align-itmes-centre justify-content-between">
                        <input class="form-control mb-2 mb-md-0 mr-md-2" type="text" placeholder="Neet Score">
                        <select class="form-control mb-2 mb-md-0 mr-md-2" id="course">
                            <option value="">SELECT STATE PREFERENCE</option>
                        </select>
                        <select class="form-control mb-2 mb-md-0 mr-md-2" id="course">
                            <option value="">SELECT HOME/DOMICILE STATE</option>
                        </select>
                        <select class="form-control mb-2 mb-md-0 mr-md-2" id="category">
                            <option value="">SELECT CATEGORY</option>
                        </select>
                        <div class="d-flex align-itmes-centre justify-content-center">
                            <button type="button" onclick="submit_rank('page')" class="rounded main-btn-bk border-0 py-2 px-4 text-white ">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid testi py-6 position-relative" id="testi">
        <div class="container position-relative">
            <div class="row">
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Karnataka NEET Colleges & Seats 2020</h2>
                        <div class="post-body">
                            <?php include_once("includes/state-map.php"); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-0">
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <div class="d-flex">
                                <button class="clgbtn clgbtn20 active" onclick="$('.c2020').show(); $('.c2019').hide(); $('.clgbtn20').addClass('active'); $('.clgbtn19').removeClass('active'); ">No. of Colleges 2020</button>
                                <button class="clgbtn clgbtn19" onclick="$('.c2020').hide(); $('.c2019').show(); $('.clgbtn20').removeClass('active'); $('.clgbtn19').addClass('active');">No. of Colleges 2019</button>

                            </div>
                            <div class="post-body">
                                <div class="colage-wrap c2020">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>100</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>100</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="colage-wrap c2019" style="display: none;">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>200</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-university"></i></p>
                                            <h5>50</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="indicate">
                                    <p class="demed-ind"><span></span>Private</p>
                                    <p class="gov-ind"><span></span>Goverment</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <div class="d-flex">
                                <button class="clgbtn seatbtn20 active" onclick="$('.s2020').show(); $('.s2019').hide(); $('.seatbtn20').addClass('active'); $('.seatbtn19').removeClass('active'); ">No. of Colleges 2020</button>
                                <button class="clgbtn seatbtn19" onclick="$('.s2020').hide(); $('.s2019').show(); $('.seatbtn20').removeClass('active'); $('.seatbtn19').addClass('active');">No. of Colleges 2019</button>

                            </div>
                            <div class="post-body">
                                <div class="colage-wrap s2020">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>100</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>100</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="colage-wrap s2019" style="display: none;">
                                    <div class="colage-box">
                                        <div class="collage-cell demed">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>200</h5>
                                        </div>
                                        <div class="collage-cell gov">
                                            <p><i class="fas fa-chair"></i></p>
                                            <h5>50</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="indicate">
                                    <p class="demed-ind"><span></span>Private</p>
                                    <p class="gov-ind"><span></span>Goverment</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 p-0">
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <h2 class="post-head">Score Vs Budget Fee 2020 - Karnataka </h2>
                            <div class="post-body">
                                <canvas id="myChart1" class="wow"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 p-3">
                        <div style="border-radius: 15px; overflow:hidden;">
                            <h2 class="post-head">Seat Distribution 2020</h2>
                            <div class="post-body">
                                <div class="col-6 offset-3">
                                    <canvas id="myChart2" class="wow"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Domicile Condition</h2>
                        <div class="post-body">
                            <div class="costshift-box">
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#6d53dc">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#6d53dc;">85% Government</h4>
                                        <h5>Only Karnataka Candidates Can Apply</h5>
                                    </div>
                                </div>
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#dc5356">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#dc5356;">100% Private</h4>
                                        <h5>Outside State Candidates Can Apply</h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Fee Range 2020</h2>
                        <div class="post-body">
                            <div class="costshift-box">
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#6d53dc">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#6d53dc;">Government</h4>
                                        <h5>INR 50,000 to 1,00,000</h5>
                                    </div>
                                </div>
                                <div class="overshift-req-box">
                                    <div class="overtime-bar" style="color:#dc5356">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="overtime-value">
                                        <h4 style="color:#dc5356;">Private</h4>
                                        <h5>INR 6,29,000 to 20,15,000</h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-5 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Government Cutoff Rank 2020</h2>
                        <div class="post-body">
                            <canvas id="myChart" class="wow"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Recognised V/S Permitted Colleges</h2>
                        <div class="post-body">
                            <div class="col-6 offset-3">
                                <canvas id="myChart5" class="wow"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Candidates Participated</h2>
                        <div class="post-body">
                            <div class="colage-wrap c2020">
                                <div class="colage-box">
                                    <div class="collage-cell demed">
                                        <p><i class="fas fa-male"></i></p>
                                        <h5>100</h5>
                                    </div>
                                    <div class="collage-cell gov">
                                        <p><i class="fas fa-male"></i></p>
                                        <h5>100</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="indicate">
                                <p class="demed-ind"><span></span>Candidates in 2020</p>
                                <p class="gov-ind"><span></span>Candidates in 2019</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Private Cutoff Rank 2020</h2>
                        <div class="post-body">
                            <canvas id="myChart3" class="wow"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 p-3">
                    <div style="border-radius: 15px; overflow:hidden;">
                        <h2 class="post-head">Karnataka Counselling Statistics - NEET 2020</h2>
                        <div class="post-body">
                            <table class="table table-1 gov-1">
                                <thead>
                                    <tr>
                                        <th class="uni seat-1" scope="col">College Name</th>
                                        <th class="fet seat" scope="col">City</th>
                                        <th class="uni seat" scope="col">College Type</th>
                                        <th class="fet seat" scope="col">Seat Type</th>
                                        <th class="uni seat-1" scope="col">Catagory</th>
                                        <th class="uni seat-1" scope="col">Annual Fees</th>
                                        <th class="fet seat-1" scope="col">Cutoff R1 Score</th>
                                        <th class="uni seat-1" scope="col">Cutoff R2 Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Bangalore Medical College and Research Institute</td>
                                        <td>Bangalore</td>
                                        <td>Government</td>
                                        <td>Government</td>
                                        <td>GM</td>
                                        <td>59850</td>
                                        <td>650</td>
                                        <td>647</td>
                                    </tr>
                                    <tr>
                                        <td>Bangalore Medical College and Research Institute</td>
                                        <td>Bangalore</td>
                                        <td>Government</td>
                                        <td>Government</td>
                                        <td>3BG</td>
                                        <td>59850</td>
                                        <td>641</td>
                                        <td>641</td>
                                    </tr>
                                    <tr>
                                        <td>Bangalore Medical College and Research Institute</td>
                                        <td>Bangalore</td>
                                        <td>Government</td>
                                        <td>Government</td>
                                        <td>3AG</td>
                                        <td>59850</td>
                                        <td>638</td>
                                        <td>633</td>
                                    </tr>
                                    <tr>
                                        <td>Mysore Medical College and Research Institute</td>
                                        <td>Mysore</td>
                                        <td>Government</td>
                                        <td>Government</td>
                                        <td>GM</td>
                                        <td>59850</td>
                                        <td>635</td>
                                        <td>630</td>
                                    </tr>
                                    <tr>
                                        <td>Bangalore Medical College and Research Institute</td>
                                        <td>Bangalore</td>
                                        <td>Government</td>
                                        <td>Government</td>
                                        <td>GMR</td>
                                        <td>59850</td>
                                        <td>635</td>
                                        <td>635</td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once("includes/footer.php"); ?>

</body>
<script>
    var ctx = document.getElementById("myChart");
    ctx.height = 115;
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Generl", "OBC", "SC", "ST"],
            datasets: [{
                label: 'Round 1',
                data: [120000, 190000, 30000, 170000],
                backgroundColor: "#fdaf4b"
            }, {
                label: 'Round 2',
                data: [30000, 290000, 500000, 5000000],
                backgroundColor: "#5fb7e5"
            }]
        },

    });
</script>
<script>
    var ctx1 = document.getElementById("myChart1");
    ctx1.height = 65;
    var myChart1 = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: ["650-600", "600-550", "550-450", "450-300"],
            datasets: [{
                label: 'Fee Per Year',
                data: [120000, 190000, 30000, 170000],
                backgroundColor: "#fdaf4b",
            }]
        },
        options: {
            legend: {
                display: false //This will do the task
            }
        },
    });
</script>

<script>
    var ctx2 = document.getElementById("myChart2");
    ctx2.height = 10;

    var myChart2 = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: ["AIQ", "Goverment", "Private", "Gov. Aided", "NRI", "Mgmt"],
            datasets: [{
                backgroundColor: [
                    "#0f3c59",
                    "#ff003f",
                    "#d60da4",
                    "#fdaf4b",
                    "#5fb7e5",
                    "#00863f"
                ],

                data: [10, 30, 20, 5, 25, 20]
            }]
        },
        options: {
            legend: {
                display: false //This will do the task
            }
        },
    });
</script>
<script>
    var ctx3 = document.getElementById("myChart3");
    ctx3.height = 110;
    var myChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
            labels: ["Generl", "OBC", "SC", "ST"],
            datasets: [{
                label: 'Round 1',
                data: [120000, 190000, 30000, 170000],
                backgroundColor: "#fdaf4b"
            }, {
                label: 'Round 2',
                data: [30000, 290000, 500000, 5000000],
                backgroundColor: "#5fb7e5"
            }]
        },

    });
</script>
<script>
    var ctx5 = document.getElementById("myChart5");
    ctx5.height = 90;
    var myChart5 = new Chart(ctx5, {
        type: 'doughnut',
        data: {
            labels: ["Recognised", "Permitted"],
            datasets: [{
                backgroundColor: [
                    "#fa445f",
                    "#0dd61d"
                ],

                data: [10, 30]
            }]
        }
    });
</script>
<script>
    var ctx6 = document.getElementById("myChart6");
    ctx6.height = 90;
    var myChart6 = new Chart(ctx6, {
        type: 'doughnut',
        data: {
            labels: ["AFMC", "IP University", "Delhi University", "Central University", "JIPMER", "AIIMS"],
            datasets: [{
                backgroundColor: [
                    "#0f3c59",
                    "#ff003f",
                    "#d60da4",
                    "#fdaf4b",
                    "#5fb7e5",
                    "#00863f"
                ],

                data: [10, 30, 20, 5, 25, 20]
            }]
        }
    });
</script>
<script>
    var bars = document.querySelectorAll('.meter > span');
    console.clear();

    setInterval(function() {
        bars.forEach(function(bar) {
            var getWidth = parseFloat(bar.dataset.progress);

            for (var i = 0; i < getWidth; i++) {
                bar.style.width = i + '%';
            }
        });
    }, 500);
</script>

</html>