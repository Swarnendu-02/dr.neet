<?php include_once("includes/pagesource.php"); ?>

<body >
    <?php include_once("includes/header.php"); ?>
    <div class="inner-banner banner position-relative predicter-banner">
        <img src="images/maxim-ilyahov-0aRycsfH57A-unsplash.jpg">
        <div class="banner-inner-content">
            <div class="text-center w-100">
                <h2 class="text-white mb-3">Notifications</h2>
            </div>
        </div>
    </div>
    <div class="container-fluid testi py-6 position-relative" id="testi">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 noti-grid">
                    <div class="blog-card main-bk  rounded position-relative" >
                        <div class="blog-image rounded">
                            <img src="images/Projects_38_cover-scaled.webp" class="h-100 ">
                        </div>
                        <div class="p-4">
                            <h6 style="    color: #E15400;">23th Feb, 2021</h6>
                            <h4 class="mb-3">Preparing for Joint Entrance Examination? It’s better to be informed than sorry!</h4>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white  ml-0" >Read More</button>
                        </div>

                    </div>
                    <div class="blog-card main-bk  rounded position-relative" >
                        <div class="blog-image rounded">
                            <img src="images/3.jpg" class="h-100 ">
                        </div>
                        <div class="p-4">
                            <h6 style="    color: #E15400;">23th Feb, 2021</h6>
                            <h4 class="mb-3">Preparing for Joint Entrance Examination? It’s better to be informed than sorry!</h4>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white  ml-0" >Read More</button>
                        </div>

                    </div>
                    <div class="blog-card main-bk  rounded position-relative" >
                        <div class="blog-image rounded">
                            <img src="images/Projects_42_cover.webp" class="h-100 ">
                        </div>
                        <div class="p-4">
                            <h6 style="    color: #E15400;">23th Feb, 2021</h6>
                            <h4 class="mb-3">Preparing for Joint Entrance Examination? It’s better to be informed than sorry!</h4>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white  ml-0" >Read More</button>
                        </div>

                    </div>
                    <div class="blog-card main-bk  rounded position-relative" >
                        <div class="blog-image rounded">
                            <img src="images/download.jpg" class="h-100 ">
                        </div>
                        <div class="p-4">
                            <h6 style="    color: #E15400;">23th Feb, 2021</h6>
                            <h4 class="mb-3">Preparing for Joint Entrance Examination? It’s better to be informed than sorry!</h4>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white  ml-0" >Read More</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include_once("includes/footer.php"); ?>

</body>


</html>