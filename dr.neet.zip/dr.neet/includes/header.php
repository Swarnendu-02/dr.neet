<header class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-9 col-md-3">
                <div class="bg-white d-flex align-items-center justify-content-center logo-sub-box" onclick="window.location.href='https://www.vidiyarthi.com/index'" style="cursor:pointer;">
                    <img src="images/logo.png">
                </div>
            </div>
            <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                <button onclick="$('.navigation').addClass('open');" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                <nav class="navigation" id="navigationmenu">
                    <button class="d-md-none" onclick="$('.navigation').removeClass('open');" style="    position: absolute;
    right: 19px;
    border: 0;
    background: transparent;
    color: white;
    top: 14px;
    font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                    <ul>
                        <li class="pb-4 pb-md-2" onclick="window.location.href='index.php'">Home</li>
                        <!-- <li class="pb-4 pb-md-2">Neet 2021</li> -->
                        <li>
                            <a onclick="$('.sub-ul').slideToggle();">College Predictor<span style="    margin-left: 6px;"><i class="fas fa-caret-down"></i></span></a>
                            <ul class="sub-ul">
                                <li onclick="window.location.href='all-india-predictor.php'">All India Predictor</li>
                                <li onclick="window.location.href='state-predictor.php'">State Predictor</li>
                            </ul>
                        </li>
                        <li class="pb-4 pb-md-2" onclick="window.location.href='notification.php'">Notification</li>

                        <button class="rounded main-btn-bk border-0 py-2 px-4 text-white ml-md-4"  onclick="$('.side-menu').addClass('menuopen'); $('body').addClass('overflow-hidden position-relative'); $('.login').removeClass('d-none'); $('.register').addClass('d-none');">Login</button>
                        <button href="javascript:void(0);" onclick="$('.side-menu').addClass('menuopen'); $('body').addClass('overflow-hidden position-relative'); $('.register').removeClass('d-none'); $('.login').addClass('d-none');" class="rounded main-btn-bk border-0 py-2 px-4 text-white ml-md-2">Register</button>
                        <!-- <li onclick="regindown()" class="slow logsignbtndec">Sign Up</li> -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<div class="side-menu">
    <a href="javascript:void(0);" class="menu-cross" onclick="$('.side-menu').removeClass('menuopen'); $('body').removeClass('overflow-hidden position-relative');  ">
        <div class="bar-1"></div>
        <div class="bar-3"></div>
    </a>
    <div class="h-100">
        <div class="col-12 getfrm login d-none">
            <form id="contactForm" class="row m-0 p-0" onsubmit="return submitLoginForm();">
                <div class="col-12 form-group ">
                    <h3>Login</h3>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="email" class="form-control" id="cemail" name="cemail" placeholder="Email">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">

                        <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Password">
                    </div>
                </div>
                <div class="col-12 mb-0 form-group text-center  mt-4 mt-md-0">
                <button type="submit" class="rounded main-btn-bk border-0 py-2 px-4 text-white ml-md-4" id="submit"><span class="position-relative">Login</span></button>
                    <p class="mb-0">If you have't account ? <a href="javascript:void(0);" onclick="$('.login').addClass('d-none'); $('.register').removeClass('d-none');">Register Now</a></p>
                </div>
            </form>
        </div>
        <div class="col-12 getfrm register d-none">
            <form id="contactForm" class="row m-0 p-0" onsubmit="return submitRegistrationForm();">
                <div class="col-12 form-group ">
                    <h3>Register</h3>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Full Name">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <select type="text" class="form-control" id="courseId" name="courseId">
                            <option value="" disabled="" selected="">Select Course</option>
                            <!-- <option value="2">CRASH COURSE2 - ₹ 24,999.00</option>-->
                        </select>
                    </div>
                </div>

                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">

                        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <label class="con">UPI
                        <input type="radio" checked="checked" name="radio" style="display: none;">
                        <span class="checkmark"></span>
                    </label>
                    <label class="con">QR Code
                        <input type="radio" name="radio" style="display: none;">
                        <span class="checkmark"></span>
                    </label>
                    <label class="con">Bank Details
                        <input type="radio" name="radio" style="display: none;">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">
                        <input type="file" class="form-control" id="payupi" style="display: none;">
                        <div style="
    position: relative;
">
                            <label for="payupi" style="
    background: #094e7f;
    color: white;
    width: 84px;
    height: 43px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: .5rem;
    position: absolute;
    top: 6px;
    left: 8px;
">Select..</label>
                            <input class="form-control" style="
    padding-left: 103px;
">
                        </div>
                    </div>
                    <div class="col-12 input-from-group rounded">
                        <input type="text" class="form-control" placeholder="Enter Bank Transfer ID">
                    </div>
                </div>
                <div class="col-12 mb-0 form-group text-center  mt-4 mt-md-0">
                    <button type="submit" class="rounded main-btn-bk border-0 py-2 px-4 text-white ml-md-4" id="submit"><span class="position-relative">Register</span></button>
                    <p class="mb-0">If you have an account ? <a href="javascript:void(0);" onclick="$('.login').removeClass('d-none'); $('.register').addClass('d-none');">Login Now</a></p>
                </div>
            </form>
        </div>
    </div>
</div>