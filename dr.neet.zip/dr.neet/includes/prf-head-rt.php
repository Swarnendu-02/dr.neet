<div class="d-flex align-items-center">
    <a class="header-icon "><i class="fas fa-bell"></i></a>
    <a class="package-name">Package Name</a>
    <a class="student-profile ">
        <img src="../images/Frame 319-1.png">
        <div>
            <h4>Name</h4>
            <h5>Uniq ID</h5>
        </div>
    </a>
</div>