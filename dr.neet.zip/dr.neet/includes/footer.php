<footer class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="footer-menu col-12 col-md-3">

                <h4 class="mb-3 text-white">About Us</h4>

                <ul class="p-0 m-0">
                    <li>Get My University is India’s leading ISO 9001:2015 certified education consultancy providing data driven counselling and admission guidance for Medicine programs in India and abroad. GMU brings up the choice of colleges from different countries all under one roof.</li>

                </ul>

            </div>

            <div class="footer-menu col-12 col-md-3 mt-4 mt-md-0">

                <h4 class="mb-3 text-white">Links</h4>

                <ul class="p-0 m-0">
                    <li onclick="window.location.href='index.php'">Home</li>
                    <!-- <li>Neet 2021</li> -->
                    <li onclick="window.location.href='all-india-predictor.php'">All India Predictor</li>
                    <li onclick="window.location.href='state-predictor.php'">State Predictor</li>
                    <li onclick="window.location.href='notification.php'">Notification</li>
                </ul>

            </div>

            <div class="footer-menu col-12 col-md-3 mt-4 mt-md-0">

                <h4 class="mb-3 text-white">Contact Us</h4>

                <ul class="p-0 m-0">
                    <li><i class="fas fa-map-marker"></i> BE 403, 1st Floor, Sector : 1, Salt Lake. Kolkata - 700064</li>
                    <li><i class="fas fa-envelope"></i>info@drneet.com</li>
                    <li><i class="fas fa-mobile"></i> (+91) 9874400739 | <i class="fas fa-phone"></i> (033) 79606815</li>

                </ul>

            </div>

            <div class="footer-menu col-12 col-md-3 mt-4 mt-md-0">

                <h4 class="mb-3 text-white">Test</h4>

                <ul class="p-0 m-0">
                    <li><i class="fab fa-facebook"></i> Facebook</li>
                    <li><i class="fab fa-instagram"></i> Instagram</li>
                    <li><i class="fab fa-twitter"></i> Twitter</li>
                </ul>

            </div>



            <div class="footer-social d-md-flex align-items-center justify-content-center mt-4 rounded bg-transparent">
                <p class="mb-0 text-white" style="font-size:12px;">Copyright @ 2014 - 2023 Dr. Neet | Designed by <a href="https://www.encoders.co.in/" target="_blank">Encoders</a></p>

            </div>



        </div>

    </div>

</footer>

