<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid inner-banenr banner p-0">
        <img src="images/banner-4.jpg" class="ban-bk">
        <div class="container position-relative h-100" style="z-index: 1;">
            <div class="row align-items-center h-100">
                <div class="col-12 col-md-6 banner-content">
                    <div>
                        <h2 class="animate__zoomIn animate__animated wow animated" style="visibility: visible; animation-name: zoomIn;">About Us</h2>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row ">
                <div class="col-12 abt-main-wrap">
                <img src="https://madkk.com/pasdigi/WP/PASDT/wp-content/uploads/2022/11/israel-andrade-YI_9SivVt_s-unsplash-1.jpg ">
                    <div class="col-12  abt-info">
                        <div class="col-12 main-heaing">
                            <h2 class="animate__fadeInUp animate__animated wow">Know all about NEET-O-METER</h2>
                        </div>
                        <div class="content">
                            <p class="animate__fadeInUp animate__animated wow">Visual learning has consistently been more obvious contrasted with coursebook learning. Web-based learning has gotten extremely well known throughout the long term, as we can see numerous sites and Apps are concocting creative plans to show students in a simple and proficient manner. The best part about internet learning is you can upgrade your abilities by looking for numerous courses all at once.</p>

                            <p class="animate__fadeInUp animate__animated wow">NEET-O-METER< is an internet coaching stage with a virtual learning stage called WAVE. The essential focal point of V class is to make learning simple for every one of the students in various pieces of India. In contrast to different stages, V class permits the students to connect with their educator’s live session. it is an online instructive stage giving training to IIT JEE and NEET students.</p>
                                    <p class="animate__fadeInUp animate__animated wow">Alongside standard instruction, one of the greatest income eaters in the nation is the equal training framework which has been helpfully named as the Coaching area. There are countless training classes assisting the students with learning the ideas they have learned in schools and amend for their tests. There are towns and regions which have grown absolutely because of this training insanity.
                                    </p>
                                    <p class="animate__fadeInUp animate__animated wow">Any insurgency in instruction can't begin in standard training, it needs to begin and infiltrate in the equal schooling framework first. This is the place where the V class has had the option to make an imprint. We don't supplant the school or the school. We at present focus on supplanting the equal instruction framework. The idea of gaining from the solace of home at a lot lesser expenses makes these applications an exceptionally appealing suggestion for the students.
                                    </p>
                                    <p class="animate__fadeInUp animate__animated wow">Our way of life actually has the significant signs of an instructor and an actual learning measure. It will take us a significant social move and a generational change to supplant this learning interaction with a virtual learning climate.
                                    </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/whyus.php"); ?>

    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 abt-grid">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <div class="col-12 main-heaing">
                                <h2 class="animate__fadeInUp animate__animated wow ">Be more ready with getting classes from NEET-O-METE</h2>
                            </div>
                            <div class="col-12 content animate__fadeInUp animate__animated wow ">
                                <p>With the assistance of web-based learning, schooling can arrive at all edges of India, there will not be any boundaries and you can get quick test outcomes that assist you with advancing to improve your abilities. You can get study materials, recordings, and counterfeit tests when you pick internet learning over customary learning. Online courses are moderate contrasted with customary schooling.

                                    65% of the students who are planning for JEE Main, NEET, and IIT may receive total web-based learning by 2021. There are countless versatile applications and sites accessible in the market for web-based learning, the fast spread of the web among all districts of India is additionally significant for this web-based learning. But at V class you will get the best service.</p>
                                <!-- <a href="#" class="main-btn-red mt-5">Know More</a> -->
                            </div>
                        </div>
                        <img src="https://madkk.com/pasdigi/WP/PASDT/wp-content/uploads/2022/11/razvan-chisu-Ua-agENjmI4-unsplash-1.jpg " class="animate__fadeInUp animate__animated wow ">
                    </div>
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <div class="col-12 main-heaing">
                                <h2 class="animate__fadeInUp animate__animated wow ">Know our vision to create an educated world</h2>
                            </div>
                            <div class="col-12 content animate__fadeInUp animate__animated wow ">
                                <p>A debut instructing establishment for the planning of JEE (Main+Advanced), JEE (Main), Pre-Medical (NEET-UG). NEET-O-METE is very much respected for the excellent selection test readiness and creates the best outcomes quite a long time after year. At V class, we center around building a solid establishment of information and ideas in students for their prosperity and give a magnificent stage to the planning of serious tests. The best scholastic help and individual consideration which we give to the students assist them with meeting their vocation objectives and goals. The basic beliefs of Determination, Honesty, Authenticity, Integrity, Devotion, Humanism, Holistic Learning, Social Ethics, and worry for society and climate are on the whole intently entwined into the fiber of our scholarly projects. Our exceptionally qualified and most experienced resources are devoted and focused on understudy's finished achievement and give assistive environmental factors to add to their social, social, scholastic, and all-around advancement.</p>
                                <!-- <a href="#" class="main-btn-red mt-5">Know More</a> -->
                            </div>
                        </div>
                        <img src="https://madkk.com/pasdigi/WP/PASDT/wp-content/uploads/2022/11/jhon-jim-5BIbTwXbTWk-unsplash-1.jpg " class="animate__fadeInUp animate__animated wow ">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/testimonial.php"); ?>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/odometer.js"></script>
<script src="js/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
<script>
    $(document).ready(function() {
        $('.has-arrow').click(function() {
            if ($(this).hasClass("active")) {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
            } else {
                $(".sub-ui").slideUp();
                $(".has-arrow").removeClass("active");
                $(this).parent().find(".sub-ui").slideToggle();
                $(this).parent().find(".has-arrow").toggleClass("active");
            }
        });
    });
</script>
<script>
    AOS.init({
        easing: 'ease-in-out-sine'
    });

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,

        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1200: {
                items: 3,
                nav: true,
            },
            1500: {
                items: 4,
                nav: true,
            }
        }
    })

    $('.client-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 6
            }
        }
    })

    $('.banner-owl').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        margin: 0,
        nav: false,
        dots: true,
        animateOut: 'fadeOut',
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })

    $('.testi-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1200: {
                items: 1
            },
            1500: {
                items: 1
            }
        }
    })
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })
    $(document).ready(function() {
        $('.tablinks').click(function() {
            $(".tabcontent").removeClass('active');
            $(".tabcontent[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tablinks").removeClass('active-a');
            $(this).addClass('active-a');
        });
        $('.tab-links').click(function() {
            $(".tab-content").removeClass('active');
            $(".tab-content[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tab-links").removeClass('active-a');
            $(this).addClass('active-a');
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
            if ($(".drop-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                $(".drop-menu").hide().removeClass('active');
                $(".has-drop").removeClass('active-a');
                $(".has-drop").removeClass('active');
            } else {
                $(".drop-menu").hide().removeClass('active');
                $(".drop-menu[data-id='" + $(this).attr('data-id') + "']").show().addClass("active");
                $(".has-drop").removeClass('active-a');
                $(this).parent().find(".has-drop").addClass('active-a');
                $(this).parent().find(".has-drop").addClass('active');
            }
        });
    });
</script>
<script src="js/wow.js"></script>
<script>
    new WOW().init();

    function gotoTop(top) {

        $("html, body").animate({

            scrollTop: top + "px"

        }, 'slow');

    }
</script>

</html>